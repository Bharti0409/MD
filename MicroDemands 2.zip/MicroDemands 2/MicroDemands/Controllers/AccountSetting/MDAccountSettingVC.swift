import UIKit

class MDAccountSectionTableCell : UITableViewCell{
    @IBOutlet weak var titleLabel    : UILabel?
}
class MDAccountRowTableCell : UITableViewCell{
    @IBOutlet weak var leftIcon      : UIImageView?
    @IBOutlet weak var titleLabel    : UILabel?
    @IBOutlet weak var subTitleLabel : UILabel?
    @IBOutlet weak var arrowView     : UIView?
    @IBOutlet weak var switchView    : UIView?
    @IBOutlet weak var switchBtn     : UISwitch?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.switchBtn?.transform = CGAffineTransformMakeScale(0.75, 0.75);
    }
}

class MDAccountSettingVC: UITableViewController {


    var dataArray : [MDAccountSettingMC] = []


    //MARK: - VIEW DID LOAD
    override func viewDidLoad() {
        super.viewDidLoad()
        DispatchQueue.main.async {
            self.tabBarController?.tabBar.isHidden = false
            self.navigationController?.isNavigationBarHidden = false


            self.dataArray = MDAccountSettingMC.getAccountSettingSerctionData()
            self.tableView.reloadData()
            //MARK: - HIDE NAV BAR 
        }
        
    }
   

    override func numberOfSections(in tableView: UITableView) -> Int {
        return (self.dataArray.count > 0) ? self.dataArray.count : 0
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        if (self.dataArray.count > 0) {
            let model = self.dataArray[section]
            return ((model.dataRowArray?.count ?? 0) > 0) ? (model.dataRowArray?.count ?? 0) : 0
        }
        return 0
    }

    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {

        if let cell = tableView.dequeueReusableCell(withIdentifier: "MDAccountSectionTableCell") as? MDAccountSectionTableCell {
            if (self.dataArray.count > 0) {
                let model = self.dataArray[section]
                cell.titleLabel?.text = model.title ?? ""
            }
            return cell.contentView
        }
        return UIView()
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        if let cell = tableView.dequeueReusableCell(withIdentifier: "MDAccountRowTableCell", for: indexPath) as? MDAccountRowTableCell {

            if (self.dataArray.count > 0) {
                let model = self.dataArray[indexPath.section]
                if ((model.dataRowArray?.count ?? 0) > 0) {
                    let rowModel = model.dataRowArray?[indexPath.row]
                    cell.leftIcon?.image = UIImage(named: rowModel?.logoImg ?? "")
                    cell.titleLabel?.text = rowModel?.title ?? ""
                    cell.subTitleLabel?.text = rowModel?.subTitle ?? ""

                    if (indexPath.section == 1) {
                        cell.arrowView?.isHidden = true
                        cell.switchView?.isHidden = false
                    } else {

                        cell.switchBtn?.transform = CGAffineTransformMakeScale(0.75, 0.75);
                        cell.arrowView?.isHidden  = false
                        cell.switchView?.isHidden = true
                    }
                }
            }
            return cell
        }
        return UITableViewCell()
    }

    

    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {

        return (section == 0) ? 0 : 50

        }

    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {

       return 72

    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (indexPath.section == 0)
        {
            self.didSelectFirstRowSection(indexPath: indexPath)
         
        }
       
        
      

    }
    override func viewWillAppear(_ animated: Bool) {

            super.viewWillAppear(animated)

            //navigationController?.setNavigationBarHidden(false, animated: animated)
        
       self.tabBarController?.tabBar.isHidden = false
        //self.navigationController?.navigationBar.isHidden = false
        self.navigationController?.navigationBar.backItem?.title = "Account Setting"

        


        }

        override func viewWillDisappear(_ animated: Bool) {

            super.viewWillDisappear(animated)


        }
    
    
    func didSelectFirstRowSection(indexPath:IndexPath)
    {
        switch indexPath.row
        {
        case 0 :
            let VC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MDProfileSettingVC") as! MDProfileSettingVC
            
            let model = self.dataArray[indexPath.section]
            let rowModel = model.dataRowArray?[indexPath.row]
            VC.navTitle = rowModel?.title  ?? ""
            self.navigationController?.pushViewController(VC, animated: false)

        case 1 :
            let VC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MDPasswordChangeVC") as! MDPasswordChangeVC
            let model = self.dataArray[indexPath.section]
            let rowModel = model.dataRowArray?[indexPath.row]
            VC.navTitle = rowModel?.title  ?? ""
            self.navigationController?.pushViewController(VC, animated: false)
            
        case 2 :
            let VC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MDPaymentCardTypeVC") as! MDPaymentCardTypeVC
            let model = self.dataArray[indexPath.section]
            let rowModel = model.dataRowArray?[indexPath.row]
            VC.navTitle = rowModel?.title  ?? ""
            self.navigationController?.pushViewController(VC, animated: false)
            
        case 3 :
            let VC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MDLocationVC") as! MDLocationVC
            let model = self.dataArray[indexPath.section]
            let rowModel = model.dataRowArray?[indexPath.row]
            VC.navTitle = rowModel?.title  ?? ""
            self.navigationController?.pushViewController(VC, animated: false)
            
        case 4:
            let VC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MDSocialMediaAccountVC") as! MDSocialMediaAccountVC
            let model = self.dataArray[indexPath.section]
            let rowModel = model.dataRowArray?[indexPath.row]
            VC.navTitle = rowModel?.title  ?? ""
            self.navigationController?.pushViewController(VC, animated: false)
            
        case 5:
            let VC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MDReferalVC") as! MDReferalVC
            let model = self.dataArray[indexPath.section]
            let rowModel = model.dataRowArray?[indexPath.row]
            VC.navTitle = rowModel?.title ?? ""
            self.navigationController?.pushViewController(VC, animated: false)
        default:  break
        }
        
        
   
    }
    
}




