//
//  MDLocationVC.swift
//  MicroDemands
//
//  Created by APPLE on 10/10/22.
//

import UIKit
class LocationCell: UITableViewCell
{
    weak var parent : UIViewController?
    @IBOutlet weak var button: UIButton?
  

        
    
    
}

class MDLocationVC: UIViewController {
    var navTitle: String? = nil
    @IBOutlet weak var table: UITableView?
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @objc func buttonAction(sender: UIButton)
    {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
             let vc = storyboard.instantiateViewController(withIdentifier: "MDAccountSettingVC")as? MDAccountSettingVC
             self.navigationController?.pushViewController(vc!, animated: true)
    }
  

}
extension MDLocationVC:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "LocationCell") as? LocationCell
      //  cell?.button?.tag = indexPath.row
        cell?.button?.addTarget(self, action: #selector(buttonAction(sender: )), for: .touchUpInside)
        return cell ?? UITableViewCell()
    }
   
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 400
        
    }
    
    
}
