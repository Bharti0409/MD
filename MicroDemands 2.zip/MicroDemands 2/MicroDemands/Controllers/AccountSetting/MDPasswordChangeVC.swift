//
//  MDProfileSettingVC.swift
//  MicroDemands
//
//  Created by APPLE on 26/09/22.
//

import UIKit
class MDPasswordcell: UITableViewCell
{
    
}
class MDPasswordChangeVC: UIViewController {
    var navTitle : String? = nil
    @IBOutlet weak var tableView: UITableView?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabBarController?.tabBar.isHidden = true
        self.navigationController?.navigationBar.backItem?.title = ""
        self.title = navTitle

    }
    

    
}
extension MDPasswordChangeVC: UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MDPasswordcell", for: indexPath)as? MDPasswordcell
        return cell ?? UITableViewCell()
    }
    
    
     func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 1
    }
    
    override func viewWillAppear(_ animated: Bool) {
      
          //  super.viewWillAppear(animated)
    }
}


