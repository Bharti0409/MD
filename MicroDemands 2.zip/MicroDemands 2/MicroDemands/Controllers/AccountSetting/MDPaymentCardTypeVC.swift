

import UIKit

class AddCardTypeTableCell: UITableViewCell {
    @IBOutlet weak var cardTypeLabel : UILabel?
    @IBOutlet weak var addCardButton : UIButton?
}

class CollCell: UITableViewCell
{
    @IBOutlet weak var cardImage : UIImageView?
    
    @IBOutlet weak var cardType : UILabel?
    
    @IBOutlet weak var subTitle : UILabel?
    
}
class MDPaymentCardTypeVC: UIViewController {
    var navTitle : String? = nil
    var dataArray:[MDPaymentMC] = []
    
    
    @IBOutlet weak var tableView: UITableView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabBarController?.tabBar.isHidden = true
        self.navigationController?.navigationBar.backItem?.title = ""
        self.title = navTitle
        self.dataArray = MDPaymentMC.getData()
    }
}

extension MDPaymentCardTypeVC: UITableViewDelegate,UITableViewDataSource
{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if (section == 0) {
            return (self.dataArray.count > 0) ? self.dataArray.count : 0
        } else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return (section == 0) ? 0.01 : 100
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {

        if (section == 1) {
            let cell = tableView.dequeueReusableCell(withIdentifier: "AddCardTypeTableCell") as? AddCardTypeTableCell
            cell?.addCardButton?.addTarget(self, action: #selector(clickedOnAddCardButton), for: .touchUpInside)
            return cell?.contentView ?? UIView()
        } else {
            return UIView()
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        if (indexPath.section == 0) {
            let cell = tableView.dequeueReusableCell(withIdentifier: "CollCell", for: indexPath) as? CollCell
            if (self.dataArray.count > 0) {
                let model = self.dataArray[indexPath.row]
                cell?.cardImage?.image = UIImage(named : model.image ?? "")
                cell?.cardType?.text = model.cardType
                cell?.subTitle?.text = model.subTitle
            }
            return cell ?? UITableViewCell()
        } else {
            return UITableViewCell()
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 65
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let VC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MDPaymentMethodVC") as! MDPaymentMethodVC
        self.navigationController?.pushViewController(VC, animated: false)
    }

    //MARK: - ADD CARD BUTTON
    @objc func clickedOnAddCardButton(sender:  UIButton) {
        
    }
}




