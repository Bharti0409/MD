//
//  MDReferalVC.swift
//  MicroDemands
//
//  Created by APPLE on 10/10/22.
//

import UIKit
class ReferalCell: UITableViewCell
{
    @IBOutlet weak var cardBackgroundImage : UIImageView?
    @IBOutlet weak var cardImage : UIImageView?
    @IBOutlet weak var referTitle: UILabel?
    @IBOutlet weak var referSubTitle: UILabel?
    @IBOutlet weak var referLink: UILabel?
    @IBOutlet weak var linkImg: UIImageView?
    


}

class MDReferalVC: UIViewController {

    var navTitle : String? = nil
    var dataArray : [MDReferalMC] = []

    @IBOutlet weak var tableView: UITableView?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabBarController?.tabBar.isHidden = true
        self.navigationController?.navigationBar.backItem?.title = ""
        self.title = navTitle
        self.dataArray = MDReferalMC.getData()

    }
    

    
}
extension MDReferalVC: UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if (indexPath.section == 0) {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "ReferalCell", for: indexPath)as? ReferalCell
            if (self.dataArray.count > 0)
            {
                let model = self.dataArray[indexPath.row]
                cell?.cardBackgroundImage?.image = UIImage(named: model.cardBackgroundImage ?? "")
                cell?.cardImage?.image = UIImage(named: model.cardImage ?? "")
                cell?.referTitle?.text = model.referTitle ?? ""
                cell?.referSubTitle?.text = model.referSubTitle ?? ""
                cell?.linkImg?.image = UIImage(named: model.linkImage ?? "")
                cell?.referLink?.text = model.referLink ?? ""
            }
            
            return cell ?? UITableViewCell()
        }
        else
        {
            return UITableViewCell()
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 400
    }
    
    
}
