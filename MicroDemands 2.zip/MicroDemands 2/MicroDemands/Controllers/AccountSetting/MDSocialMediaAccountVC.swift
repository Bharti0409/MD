//
//  MDSocialMediaAccountVC.swift
//  MicroDemands
//
//  Created by APPLE on 10/10/22.
//

import UIKit
class AccountHandelingCell: UITableViewCell
{
    
}

class MDSocialMediaAccountVC: UIViewController {
    var navTitle : String? = nil

    @IBOutlet weak var table : UITableView?
    override func viewDidLoad() {
        super.viewDidLoad()
        super.viewDidLoad()
        self.tabBarController?.tabBar.isHidden = true
        self.navigationController?.navigationBar.backItem?.title = ""
        self.title = navTitle

    }
    

   

}
extension MDSocialMediaAccountVC:UITableViewDelegate,UITableViewDataSource
{
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"AccountHandelingCell") as? AccountHandelingCell
        return cell ?? UITableViewCell()
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 400
    }
    
    
    
    
}
