//
//  LoginViewController.swift
//  MicroDemands
//
//  Created by APPLE on 20/09/22.
//
import UIKit
import MBProgressHUD
import Alamofire
import Reachability

class LoginViewController:  UIViewController,UITextFieldDelegate {
    var value: String = ""
    var reachability:Reachability?
    //MARK: - VIEW
    
    @IBOutlet weak var emailView: UIView?
    @IBOutlet weak var passwordView: UIView?
    //MARK: - text View
    @IBOutlet weak var emailText: UITextField?
    @IBOutlet weak var passwordText: UITextField?
    @IBOutlet weak var signInButton: UIButton?
    
    
    
    //MARK: - error buttons
    @IBOutlet weak var facebookView: UIView?
    @IBOutlet weak var googleView: UIView?
    @IBOutlet weak var titleLbl: UILabel?
    @IBOutlet weak var titleTwolbl: UILabel?
    
    var iconClick = false
    let imageIcon = UIImageView()
    
    //MARK: - FORGOT PASSWORD
    @IBAction func forgotPassword(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "MDForgotPasswordVC")as? MDForgotPasswordVC
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    //MARK: - Create new ACCOUNT
    @IBAction func createNewAcc(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)

                let vc = storyboard.instantiateViewController(withIdentifier: "ViewController")as? ViewController

                self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
      
            super.viewWillAppear(animated)
    }
    @IBAction func signInButton(_ sender: UIButton) {
        
    
        if emailText?.text! != "" && passwordText?.text! != ""
        {
            //call api
            
            apiCalling()
            LocalStorage.myValue = self.value
        }
        
        else
        {
            let alert = UIAlertController(title: "", message:"please all fields are require" , preferredStyle:.alert)
            let closeAction = UIAlertAction(title: "Close", style: UIAlertAction.Style.cancel, handler:{action in
                print("close")
            })
            alert.addAction(closeAction)
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    //MARK: - Override View did load
    override func viewDidLoad() {
        super.viewDidLoad()
        design()
        //MARK: - Hide back button
        let backBarButton = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)

                navigationItem.backBarButtonItem = backBarButton

                self.navigationItem.hidesBackButton = true
        self.navigationController?.navigationBar.backItem?.title = "Login"
        
        //end here
        self.title = "Login"
    
        
    }
    
    
        //MARK: - Design
    func design()
    {
        self.googleView?.viewPropeerty()
        self.facebookView?.viewPropeerty()
        
        //MARK: eye in password field
        imageIcon.image = UIImage(systemName: "eye.slash.fill")
        let contentView = UIView()
        contentView.addSubview(imageIcon)
        contentView.frame = CGRect(x: 0, y: 0, width: UIImage(systemName: "eye.slash.fill")!.size.width, height: UIImage(systemName: "eye.slash.fill")!.size.height)
        imageIcon.frame = CGRect(x: -10, y: 0, width: UIImage(systemName: "eye.slash.fill")!.size.width, height: UIImage(systemName: "eye.slash.fill" )!.size.height)
        passwordText?.rightView = contentView
        passwordText?.rightViewMode = .always
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        imageIcon.isUserInteractionEnabled = true
        imageIcon.addGestureRecognizer(tapGestureRecognizer)
    }
    @objc func imageTapped(tapGestureRecognizer:UITapGestureRecognizer)
    {
        let tappedImage = tapGestureRecognizer.view as! UIImageView
        if iconClick
        {iconClick = false
            tappedImage.image = UIImage(systemName: "eye.fill")
            passwordText?.isSecureTextEntry = false
        }
        else
        {iconClick = true
            tappedImage.image = UIImage(systemName: "eye.slash.fill")
            passwordText?.isSecureTextEntry = true
        }
    }
    

    //MARK: - api
    func apiCalling()
    {
        do{
            self.reachability = try Reachability.init()
        }
        catch {
            print("Unable to start notifier")
        }
        
        if ((reachability!.connection) != .unavailable)
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            let params = ["email":self.emailText?.text!.trimmingCharacters(in: .whitespacesAndNewlines) as AnyObject,
                          "password":self.passwordText?.text!.trimmingCharacters(in: .whitespacesAndNewlines) as AnyObject,
                          "deviceToken":"123456".trimmingCharacters(in: .whitespacesAndNewlines) as AnyObject,
                          "deviceType":"iPhones".trimmingCharacters(in: .whitespacesAndNewlines) as AnyObject,
            ]
            let encodeUrl = apiLogin
            let requestofAPI = AF.request(encodeUrl, method: .post, parameters: params, encoding:JSONEncoding.default, headers: nil, interceptor: nil)
            requestofAPI.responseJSON(completionHandler: { (response) -> Void in
                print(response.request!)
                print(response.result)
                print(response.response as Any)
                
                switch response.result{
                case .success(let payload):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    if let x = payload as? Dictionary<String,AnyObject>
                    {
                        print(x)
                            let resultValue = x as NSDictionary
                                               let code = resultValue["statusCode"] as? String
                                               let message = resultValue["message"] as! String
                        
                                               if code == "200"
                                             {
                                         //  this data stored in NSDictionary------
                                                   let data = resultValue["data"] as! NSDictionary
                                                   //------
                                                   let token = resultValue["token"] as! String
                                                  let userId = data["id"] as! Int
                                             UserDefaults.standard.set("\(userId)", forKey: "")
                                                   UserDefaults.standard.set("\(token)", forKey: "token")
                                                   
                        
                                               }
                                                else
                                                {
                                                    let alert = UIAlertController(title: "", message:"\(message)" , preferredStyle:.alert)
                                                    let closeAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.cancel, handler:{action in
                                                        print("close")
                                                        
                                                        if message == "Success"
                                                        {
                                                            let storyboard = UIStoryboard(name: "Main", bundle: nil)
                                                            
                                                            let vc = storyboard.instantiateViewController(withIdentifier: "UITabBarVC")as? UITabBarVC
                                                            
                                                            self.navigationController?.pushViewController(vc!, animated: true)
                                                        }
                                                        else
                                                        {
                                                        
                                                        }
                                                        
                                                    })
                                                    alert.addAction(closeAction)
                                                    self.present(alert, animated: true, completion: nil)
                                               }
                    }
                case.failure(let error):
                    print(error)
                }
                
            })
        }
        else
        {
             showAlertView("", message: "Please check your network")
           
        }
    }
    
    
    //MARK:  delegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
            
        case emailText:
            passwordText?.becomeFirstResponder()
            
        default:
            passwordText?.resignFirstResponder()
        }
        return true
    }
    
    
    
    
    //MARK: -Font
    
    
    
    func title()
    {
        self.titleLbl?.text = "Welcome to Micro demand Services"
        self.titleTwolbl?.text = "Enter your Phone number or Email address for sign in."
        
    }
    
    
}









