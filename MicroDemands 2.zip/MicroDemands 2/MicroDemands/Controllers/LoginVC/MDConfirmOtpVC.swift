//
//  MDConfirmOtpVC.swift
//  MicroDemands
//
//  Created by APPLE on 03/10/22.
//
import Reachability
import Alamofire
import MBProgressHUD
import UIKit

class MDConfirmOtpVC: UIViewController {
    
    //MARK: -otp resend
    @IBOutlet weak var resendCodeTimerLabel: UILabel!
      @IBOutlet weak var resendCodeButton: UIButton!
      var resendCodeCounter = 30
      var resendCodeTimer = Timer()
    
     // in case user closed the controller
      deinit {
        resendCodeTimer.invalidate()
      }
      @objc func updateTimerLabel() {
        resendCodeCounter -= 1
        resendCodeTimerLabel.text = "Resend code in \(resendCodeCounter) seconds."
        if resendCodeCounter == 0 {
          resendCodeButton.isEnabled = true
          resendCodeTimer.invalidate()
        }
      }
      @IBAction func resendAgainButtonClicked(_ sender: UIButton) {
        otpOneText?.text = ""
        resendCodeCounter = 31
        resendCodeButton.isEnabled = false
          sendOTPCode(email ?? "" , type: type ?? 3)
      }
   
    func sendOTPCode(_ email : String,type : Int)
    {
        do{
            self.reachability = try Reachability.init()
        }
        catch {
            print("Unable to start notifier")
        }
        
        if ((reachability!.connection) != .unavailable)
        {
             MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let parameters = ["email":self.email?.trimmingCharacters(in: .whitespacesAndNewlines) as AnyObject] as [String : Any]
           // "otp":self.otpOneText?.text!.trimmingCharacters(in: .whitespacesAndNewlines) as AnyObject,
           
            let requestofAPI = AF.request("http://3.239.14.157:3002/v1/customer/resendOtp", method: .post,parameters: parameters, encoding:JSONEncoding.default, headers: nil, interceptor: nil)
            requestofAPI.responseJSON(completionHandler: { (response) -> Void in
                print(response.request!) // url request
                print(response.result)
                print(response.response as Any)
                
                switch response.result{
                case .success(let payload):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    
                    if let x = payload as? Dictionary<String,AnyObject>
                        
                    {
                        print(x)
                        let resultValue = x as NSDictionary
                        let code = resultValue["statusCode"] as? String
                        let message = resultValue["message"] as! String
                        
                        
                        if (code == "1")
                        {
                            
                            //this data stored in NSDictionary------
                            let data = resultValue["data"] as! NSDictionary
                            //------
                            let token = resultValue["token"] as! String
                            let userId = data["id"] as! Int
                            UserDefaults.standard.set("\(userId)", forKey: "")
                            UserDefaults.standard.set("\(token)", forKey: "ApiToken")
                            
                            
                        }
                        else{
                            
                            if message == "Success"
                            {
                                self.resendCodeTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.updateTimerLabel), userInfo: nil, repeats: true)
                                
                            }
                            else
                            {
                                
                            }
                            
                            print("close")
                        }
                    }
                    
                case.failure(let error):
                    print(error)
                }
                    })
}
        else
        {
            let alert = UIAlertController(title: "", message:"Please check your network" , preferredStyle:.alert)
            let closeAction = UIAlertAction(title: "Close", style: UIAlertAction.Style.cancel, handler:{action in
                print("close")
            })
            alert.addAction(closeAction)
            self.present(alert, animated: true, completion: nil)
        }
        
    }
        //Whatever your api logic
        
    
    
    

    
    var reachability: Reachability?
    var email: String? = nil
    var type: Int? = nil
    var name: String? = nil
    var phoneNo: String? = nil
    var password: String? = nil
    
    @IBOutlet weak var titleView: UIView?
    @IBOutlet weak var titleLbl: UILabel?
    @IBOutlet weak var titledes: UILabel?

    
    //MARK: - Main View
    @IBOutlet weak var decriptionLbl: UILabel?
    @IBOutlet weak var descriptionPage: UILabel?
    
    //MARK: - outlet for title text
    @IBOutlet weak var otpOneText: UITextField?
    @IBOutlet weak var otpTwoText: UITextField?
    @IBOutlet weak var otpThreeText: UITextField?
    @IBOutlet weak var otpFourText: UITextField?
    
    //MARK: - FooterIOutlets
    
    @IBOutlet weak var continueButton: UIButton?
    @IBOutlet weak var resendOTP: UIButton?
    @IBOutlet weak var otpMsgLbl: UILabel?
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.backItem?.title = " "
        self.title = "Login"
        
        titleText()

    //MARK: -otp
        resendCodeTimerLabel.text = ""
       // sendOTPCode(email ?? "")
        
    }
    
    
    
    @IBAction func `continue`(_ sender: Any) {
        apiCalling(email ?? "", type: type ?? 0)
        
        
    }
   
    
    func titleText()
    {
        self.decriptionLbl?.text = "Verify Phone Number"
        self.descriptionPage?.text = "By Signing up you agree to our Terms Conditions & Privacy Policy."
        self.titledes?.text = "Enter the 4-Digit code sent to you at                                            +610489632578"
        self.otpMsgLbl?.text = "Didn’t receive code?"
        
        continueButton?.setTitle("Continue", for: .normal)
        
        resendOTP?.setTitle("Resend OTP", for: .normal)
        
    }
    func apiCalling(_ email : String, type: Int)
    {
        do{
            self.reachability = try Reachability.init()
        }
        catch {
            print("Unable to start notifier")
        }
        
        if ((reachability!.connection) != .unavailable)
        {
             MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let parameters = ["otp":self.otpOneText?.text!.trimmingCharacters(in: .whitespacesAndNewlines) as AnyObject,"email":self.email?.trimmingCharacters(in: .whitespacesAndNewlines) as AnyObject, "type":self.type as AnyObject] as [String : Any]
            
            let encodeUrl = otpApi
            let requestofAPI = AF.request(encodeUrl, method: .put,parameters: parameters, encoding:JSONEncoding.default, headers: nil, interceptor: nil)
            requestofAPI.responseJSON(completionHandler: { (response) -> Void in
                print(response.request!) // url request
                print(response.result)
                print(response.response as Any)
                
                switch response.result{
                case .success(let payload):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    
                    if let x = payload as? Dictionary<String,AnyObject>
                        
                    {
                        print(x)
                        let resultValue = x as NSDictionary
                        let code = resultValue["statusCode"] as? String
                        let message = resultValue["message"] as! String
                        
                        if (code == "0")
                        {
                            
                            //this data stored in NSDictionary------
                            let data = resultValue["data"] as! NSDictionary
                            //------
                            let token = resultValue["token"] as! String
                            let userId = data["id"] as! Int
                            UserDefaults.standard.set("\(userId)", forKey: "")
                            UserDefaults.standard.set("\(token)", forKey: "ApiToken")
                            
                            
                        }
                        else
                        {
                            if message == "Success"
                                {
                                    switch type
                                    {
                                    case 1:
                                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                                        
                                        let vc = storyboard.instantiateViewController(withIdentifier: "LoginViewController")as? LoginViewController
                                        
                                        self.navigationController?.pushViewController(vc!, animated: true)
                                        break
                                    case 2:
                                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                                        
                                        let vc = storyboard.instantiateViewController(withIdentifier: "MDResetPasswordVC")as? MDResetPasswordVC
                                        vc?.email = self.email
                                        
                                        self.navigationController?.pushViewController(vc!, animated: true)
                                        break
                                    case 3:
                                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                                        
                                        let vc = storyboard.instantiateViewController(withIdentifier: "LoginViewController")as? LoginViewController
                                        
                                        self.navigationController?.pushViewController(vc!, animated: true)
                                        break
                                        
                                    default : break
                                    }
                                }
                                else
                                {
                                    
                                        let alert = UIAlertController(title: "", message:"\(message)" , preferredStyle:.alert)
                                        let closeAction = UIAlertAction(title: "Close", style: UIAlertAction.Style.cancel, handler:{_ -> Void in
                                })
                                alert.addAction(closeAction)
                                self.present(alert, animated: true, completion: nil)
                                }
                                
                                print("close")
                      }
                    }
                case.failure(let error):
                    print(error)
                }
                
            })
        }
        else
        {
            let alert = UIAlertController(title: "", message:"Please check your network" , preferredStyle:.alert)
            let closeAction = UIAlertAction(title: "Close", style: UIAlertAction.Style.cancel, handler:{action in
                print("close")
            })
            alert.addAction(closeAction)
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    
   
    }
    

extension UITextField
{
    func otpText()
    {
        let bottomLine = CALayer()
        bottomLine.frame = CGRect(x: 0.0, y: (self.frame.height ) - 1, width: (self.frame.width ) , height: 1.0)
        bottomLine.backgroundColor = UIColor.black.cgColor
        self.borderStyle = UITextField.BorderStyle.none
        self.layer.addSublayer(bottomLine)
    }
   
    }
