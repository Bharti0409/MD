//
//  MDForgotPasswordVC.swift
//  MicroDemands
//
//  Created by APPLE on 27/09/22.
//

import UIKit
import Alamofire
import MBProgressHUD
import Reachability

class MDForgotPasswordVC: UIViewController {

    var reachability:Reachability?
    @IBOutlet weak var emailText: UITextField?

     @IBAction func resetPasswordButton(_ sender: Any) {
        apiCalling()
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Forgot Password"
        self.navigationController?.navigationBar.backItem?.title = ""
       
    }
    
    func apiCalling()
    {
        do{
                self.reachability = try Reachability.init()
            }
            catch {
                print("Unable to start notifier")
            }
            
            if ((reachability!.connection) != .unavailable)
            {
                MBProgressHUD.showAdded(to: self.view, animated: true)
                let params = ["email":self.emailText?.text!.trimmingCharacters(in: .whitespacesAndNewlines) as AnyObject]
                let encodeUrl = forgotPassword
                let requestofAPI = AF.request(encodeUrl, method: .put, parameters: params, encoding:JSONEncoding.default, headers: nil, interceptor: nil)
                requestofAPI.responseJSON(completionHandler: { (response) -> Void in
                    print(response.request!)
                    print(response.result)
                    print(response.response as Any)
                    
                    switch response.result{
                    case .success(let payload):
                        MBProgressHUD.hide(for: self.view, animated: true)
                        if let x = payload as? Dictionary<String,AnyObject>
                        {
                            print(x)
                                let resultValue = x as NSDictionary
                                                   let code = resultValue["statusCode"] as? String
                                                   let message = resultValue["message"] as! String
                            
                                                   if code == "200"
                                                 {
                                             //  this data stored in NSDictionary------
                                                       let data = resultValue["data"] as! NSDictionary
                                                       //------
                                                       let token = resultValue["token"] as! String
                                                      let userId = data["id"] as! Int
                                                 UserDefaults.standard.set("\(userId)", forKey: "")
                                                       UserDefaults.standard.set("\(token)", forKey: "token")
                                                       
                            
                                                   }
                            else
                                                    {
                                if message == "Success"
                                {
                                    let storyBoard = UIStoryboard(name: "Main", bundle: nil)
                                    let vc = storyBoard.instantiateViewController(withIdentifier: "MDConfirmOtpVC")as? MDConfirmOtpVC
                                                            vc?.email = self.emailText?.text ?? ""
                                    vc?.type = 2
                                    self.navigationController?.pushViewController(vc!, animated: true)
                                }
                                else
                                {
                                    let alert = UIAlertController(title: "", message:"\(message)" , preferredStyle:.alert)
                                    let closeAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.cancel, handler:{action in
                                        print("close")
                                    })
                                    alert.addAction(closeAction)
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                    case.failure(let error):
                        print(error)
                    }
                    
                })
            }
            else
            {
                let alert = UIAlertController(title: "", message:"Please check your network" , preferredStyle:.alert)
                let closeAction = UIAlertAction(title: "Close", style: UIAlertAction.Style.cancel, handler:{action in
                    print("close")
                })
                alert.addAction(closeAction)
                self.present(alert, animated: true, completion: nil)
            }
    }

}
