//
//  MDResetPasswordVC.swift
//  MicroDemands
//
//  Created by APPLE on 27/09/22.
//

import UIKit
import Reachability
import Alamofire
import MBProgressHUD

class MDResetPasswordVC: UIViewController {
    var reachability:Reachability?
    var email: String? = nil
    var type: Int? = nil
    
    var iconClick = false
    let imageIcon = UIImageView()
    var statusCode:Int? = nil
    
    @IBOutlet weak var passwordText: UITextField?
    @IBOutlet weak var confirmpasswordText: UITextField?
    
    @IBAction func resetPassword(_ sender: Any) {
        if (self.passwordText?.text != self.confirmpasswordText?.text)
        {
            showAlertView("", message:  "Password &Confirm password should be same")
        }
        else
        {
            apiCalling(email ?? "")
        }
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Reset Password"
        self.navigationController?.navigationBar.backItem?.title = ""
        design()
    }
    
    func apiCalling(_ email : String)
    {
        do{
            self.reachability = try Reachability.init()
        }
        catch {
            print("Unable to start notifier")
        }
        
        if ((reachability!.connection) != .unavailable)
        {
            //MARK: - Activity Indicator
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let parameters = ["password":self.passwordText?.text!.trimmingCharacters(in: .whitespacesAndNewlines) as AnyObject,"email":self.email?.trimmingCharacters(in: .whitespacesAndNewlines) as AnyObject]
            
            // let encodeUrl = resetPassword
            let requestofAPI = AF.request("http://3.239.14.157:3002/v1/customer/reset-Password", method: .put,parameters: parameters, encoding:JSONEncoding.default, headers: nil, interceptor: nil)
            requestofAPI.responseJSON(completionHandler: { (response) -> Void in
                print(response.request!) // url request
                print(response.result)
                print(response.response as Any)
                
                switch response.result{
                case .success(let payload):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    
                    if let x = payload as? Dictionary<String,AnyObject>
                        
                    {
                        print(x)
                        let resultValue = x as NSDictionary
                        let code = resultValue["statusCode"] as? String
                        let message = resultValue["message"] as! String
                        
                        if (code == "200")
                        {
                            
                            //this data stored in NSDictionary------
                            let data = resultValue["data"] as! NSDictionary
                            //------
                            let token = resultValue["token"] as! String
                            let userId = data["id"] as! Int
                            UserDefaults.standard.set("\(userId)", forKey: "")
                            UserDefaults.standard.set("\(token)", forKey: "ApiToken")
                            
                            
                        }
                        else
                        {
                            let alert = UIAlertController(title: "", message:"\(message)" , preferredStyle:.alert)
                            let closeAction = UIAlertAction(title: "ok", style: UIAlertAction.Style.cancel, handler:{_ -> Void in
                                
                                if message == "Success"
                                {
                                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                                    
                                    let vc = storyboard.instantiateViewController(withIdentifier: "LoginViewController")as? LoginViewController
                                    
                                    self.navigationController?.pushViewController(vc!, animated: true)
                                }
                                else
                                {
                                    
                                }
                                
                                print("close")
                            })
                            alert.addAction(closeAction)
                            self.present(alert, animated: true, completion: nil)
                        }
                    }
                case.failure(let error):
                    print(error)
                }
                
            })
        }
        else
        {
            showAlertView("", message: "Please check your network")
        }
    }
        
        //MARK: -Eye
        func design()
        {
            //MARK: eye in password field
            imageIcon.image = UIImage(systemName: "eye.slash.fill")
            let contentView = UIView()
            contentView.addSubview(imageIcon)
            contentView.frame = CGRect(x: 0, y: 0, width: UIImage(systemName: "eye.slash.fill")!.size.width, height: UIImage(systemName: "eye.slash.fill")!.size.height)
            imageIcon.frame = CGRect(x: -10, y: 0, width: UIImage(systemName: "eye.slash.fill")!.size.width, height: UIImage(systemName: "eye.slash.fill" )!.size.height)
            passwordText?.rightView = contentView
            passwordText?.rightViewMode = .always
            
//            confirmpasswordText?.rightView = contentView
//           confirmpasswordText?.rightViewMode = .always
            let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
            imageIcon.isUserInteractionEnabled = true
            imageIcon.addGestureRecognizer(tapGestureRecognizer)
        }
        
        @objc func imageTapped(tapGestureRecognizer:UITapGestureRecognizer)
        {
            let tappedImage = tapGestureRecognizer.view as! UIImageView
            if iconClick
            {iconClick = false
                tappedImage.image = UIImage(systemName: "eye.fill")
                passwordText?.isSecureTextEntry = false
               // confirmpasswordText?.isSecureTextEntry = false
            }
            else
            {iconClick = true
                tappedImage.image = UIImage(systemName: "eye.slash.fill")
                passwordText?.isSecureTextEntry = true
               // confirmpasswordText?.isSecureTextEntry = true

            }
        }
        
        
    }

    
extension MDResetPasswordVC: UITextFieldDelegate
{
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
    }
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
    {
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextField.DidEndEditingReason) {
    }
    
    
    func textFieldDidChangeSelection(_ textField: UITextField)
    {
        
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField
        {
        case passwordText:
            passwordValidation()
            confirmpasswordText?.becomeFirstResponder()
       
            
        case confirmpasswordText:
            confirmpasswordText?.resignFirstResponder()
            
            
        default:
            confirmpasswordText?.resignFirstResponder()
        }
        return true
    }
    func passwordValidation()
    {
        if let password = passwordText?.text
        {
            if let alertMessage = invalidPassword(password)
            {
                showAlertView("", message: "\(alertMessage)")
            }
            else
            {
//                passwordError?.isHidden = true
            }
        }
    }
}

