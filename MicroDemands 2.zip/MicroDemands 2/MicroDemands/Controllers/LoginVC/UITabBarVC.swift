//
//  UITabBarVC.swift
//  MicroDemands
//
//  Created by APPLE on 06/10/22.
//

import UIKit


class UITabBarVC: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true

    }
    

    
}
