//
//  ViewController.swift
//  MicroDemands
//
//  Created by APPLE on 16/09/22.
//

import UIKit
import MBProgressHUD
import Alamofire
import Reachability



class ViewController: UIViewController,UITextFieldDelegate {
    
    var reachability:Reachability?
    
    
    //MARK: - VIEW
    
    @IBOutlet weak var nameView: UIView?
    @IBOutlet weak var emailView: UIView?
    @IBOutlet weak var passwordView: UIView?
    @IBOutlet weak var phoneView: UIView?
    //MARK: - text View
    @IBOutlet weak var nameText: UITextField?
    @IBOutlet weak var emailText: UITextField?
    @IBOutlet weak var passwordText: UITextField?
    @IBOutlet weak var phoneNumberText: UITextField?
    @IBOutlet weak var signUpButton: UIButton?
    
    //MARK: - ButtonView
    @IBOutlet weak var faceView: UIView?
    @IBOutlet weak var googleView: UIView?
    
    //MARK: - error buttons
    @IBOutlet weak var nameError: UILabel?
    @IBOutlet weak var emailError: UILabel?
    @IBOutlet weak var passwordError: UILabel?
    @IBOutlet weak var phoneError: UILabel?
    
    var iconClick = false
    let imageIcon = UIImageView()
    var statusCode:Int? = nil
    @IBAction func alreadyHaveAccountSignUp(_ sender: Any)
    {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "LoginViewController")as? LoginViewController
        
        self.navigationController?.pushViewController(vc!, animated: true)
        
        
    }
    @IBAction func signUpButton(_ sender: UIButton) {
        
        //   resetForm()
        
        if nameText?.text! != "" && emailText?.text! != "" && passwordText?.text! != "" && phoneNumberText?.text! != ""
        {
            //call api
            
            apiCalling()
            
        }
        
        else
        {
            let alert = UIAlertController(title: "", message:"please all fields are require" , preferredStyle:.alert)
            let closeAction = UIAlertAction(title: "Close", style: UIAlertAction.Style.cancel, handler:{action in
                print("close")
            })
            alert.addAction(closeAction)
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    //MARK: Override
    override func viewDidLoad() {
        super.viewDidLoad()
        //MARK: - hide back in back button
        let backBarButton = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        navigationItem.backBarButtonItem = backBarButton
        self.navigationController?.navigationBar.backItem?.title = ""
        //end here
        self.title = "Sign Up"
        resetForm()
        designPart()
        
        // Do any additional setup after loading the view.
        
        
        
        
        
        //MARK: eye
        
    }
    @objc func imageTapped(tapGestureRecognizer:UITapGestureRecognizer)
    {
        let tappedImage = tapGestureRecognizer.view as! UIImageView
        if iconClick
        {iconClick = false
            tappedImage.image = UIImage(systemName: "eye.fill")
            passwordText?.isSecureTextEntry = false
        }
        else
        {iconClick = true
            tappedImage.image = UIImage(systemName: "eye.slash.fill")
            passwordText?.isSecureTextEntry = true
        }
    }
    
    //MARK: - validations
    @IBAction func nameChange(_ sender: Any)
    {
        if let name = nameText?.text
        {
            if let errorMessage = invalidName(name)
            {
                nameError?.text = errorMessage
                nameError?.isHidden = false
            }
            else
            {
                nameError?.isHidden = true
            }
        }
        
        checkForValidForm()
    }
    
    func invalidName(_ value: String) -> String?
    {
        let reqularExpression = "(?<! )[-a-zA-Z' ]{2,26}"
        let predicate = NSPredicate(format: "SELF MATCHES %@", reqularExpression)
        if !predicate.evaluate(with: value)
        {
            return "Enter Valid Name"
        }
        
        return nil
    }
    @IBAction func emailChanged(_ sender: Any)
    {
        if let email = emailText?.text
        {
            if let errorMessage = invalidEmail(email)
            {
                emailError?.text = errorMessage
                emailError?.isHidden = false
            }
            else
            {
                emailError?.isHidden = true
            }
        }
        
        checkForValidForm()
    }
    
    func invalidEmail(_ value: String) -> String?
    {
        let reqularExpression = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let predicate = NSPredicate(format: "SELF MATCHES %@", reqularExpression)
        if !predicate.evaluate(with: value)
        {
            return "Invalid Email Address"
        }
        
        return nil
    }
    
    @IBAction func passwordChanged(_ sender: Any)
    {
        if let password = passwordText?.text
        {
            if let errorMessage = invalidPassword(password)
            {
                passwordError?.text = errorMessage
                passwordError?.isHidden = false
            }
            else
            {
                passwordError?.isHidden = true
            }
        }
        
        checkForValidForm()
    }
    
    
    
    
    
    @IBAction func phoneChanged(_ sender: Any)
    {
        if let phoneNumber = phoneNumberText?.text
        {
            if let errorMessage = invalidPhoneNumber(phoneNumber)
            {
                phoneError?.text = errorMessage
                phoneError?.isHidden = false
            }
            else
            {
                phoneError?.isHidden = true
            }
        }
        checkForValidForm()
    }
    
    func invalidPhoneNumber(_ value: String) -> String?
    {
        let set = CharacterSet(charactersIn: value)
        if !CharacterSet.decimalDigits.isSuperset(of: set)
        {
            return "Phone Number must contain only digits"
        }
        
        if value.count != 10
        {
            return "Phone Number must be 10 Digits in Length"
        }
        return nil
    }
    
    func checkForValidForm()
    {
        if nameError!.isHidden && emailError!.isHidden && passwordError!.isHidden && phoneError!.isHidden
        {
            signUpButton?.isEnabled = true
        }
        else
        {
            signUpButton?.isEnabled = false
        }
    }
    
    
    //MARK: - reset form
    func resetForm()
    {
        signUpButton?.isEnabled = false
        
        nameError?.isHidden = false
        emailError?.isHidden = false
        phoneError?.isHidden = false
        passwordError?.isHidden = false
        
        nameText?.text = "Required"
        emailText?.text = "Required"
        passwordText?.text = "Required"
        phoneNumberText?.text = "Required"
        
        nameText?.text = ""
        emailText?.text = ""
        passwordText?.text = ""
        phoneNumberText?.text = ""
    }
    //MARK: Design part
    
    func designPart()
    {
        
        self.faceView?.viewPropeerty()
        self.googleView?.viewPropeerty()
        
        imageIcon.image = UIImage(systemName: "eye.slash.fill")
        let contentView = UIView()
        contentView.addSubview(imageIcon)
        contentView.frame = CGRect(x: 0, y: 0, width: UIImage(systemName: "eye.slash.fill")!.size.width, height: UIImage(systemName: "eye.slash.fill")!.size.height)
        imageIcon.frame = CGRect(x: -10, y: 0, width: UIImage(systemName: "eye.slash.fill")!.size.width, height: UIImage(systemName: "eye.slash.fill" )!.size.height)
        passwordText?.rightView = contentView
        passwordText?.rightViewMode = .always
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        imageIcon.isUserInteractionEnabled = true
        imageIcon.addGestureRecognizer(tapGestureRecognizer)
    }
    
    
    //MARK: - api
    func apiCalling()
    {
        do{
            self.reachability = try Reachability.init()
        }
        catch {
            print("Unable to start notifier")
        }
        
        if ((reachability!.connection) != .unavailable)
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            let params = ["name":self.nameText?.text!.trimmingCharacters(in: .whitespacesAndNewlines) as AnyObject,
                          "email":self.emailText?.text!.trimmingCharacters(in: .whitespacesAndNewlines) as AnyObject,
                          "phoneNo":self.phoneNumberText?.text!.trimmingCharacters(in: .whitespacesAndNewlines) as AnyObject,
                          "password":self.passwordText?.text!.trimmingCharacters(in: .whitespacesAndNewlines) as AnyObject , "clientId":"632ae2b8ef50e7c52c344d6e"] as [String : Any]
            let encodeUrl = apiSignup
            let requestofAPI = AF.request(encodeUrl, method: .post, parameters: params, encoding:JSONEncoding.default, headers: nil, interceptor: nil)
            requestofAPI.responseJSON(completionHandler: { (response) -> Void in
                print(response.request!) // url request
                print(response.result)
                print(response.response as Any) //http response
                
                
                
                switch response.result{
                case .success(let payload):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    
                    if let x = payload as? Dictionary<String,AnyObject>
                        
                    {
                        print(x)
                        let resultValue = x as NSDictionary
                        let code = resultValue["statusCode"] as? String
                        let message = resultValue["message"] as! String
                        
                        if (code == "200")
                        {
                            
                            //this data stored in NSDictionary------
                            let data = resultValue["data"] as! NSDictionary
                            //------
                            let token = resultValue["token"] as! String
                            let userId = data["id"] as! Int
                            UserDefaults.standard.set("\(userId)", forKey: "")
                            UserDefaults.standard.set("\(token)", forKey: "ApiToken")
                            
                            
                        }
                        else
                        {
                            let alert = UIAlertController(title: "", message:"\(message)" , preferredStyle:.alert)
                            let closeAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.cancel, handler:{_ -> Void in
                                
                                if message == "Success"
                                {
                                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                                    
                                    let vc = storyboard.instantiateViewController(withIdentifier: "MDConfirmOtpVC")as? MDConfirmOtpVC
                                    vc?.email = self.emailText?.text ?? ""
                                    vc?.type = 1
                                    self.navigationController?.pushViewController(vc!, animated: true)
                                }
                                else
                                {
                                    
                                }
                                
                                
                                print("close")
                            })
                            alert.addAction(closeAction)
                            self.present(alert, animated: true, completion: nil)
                            
                            
                        }
                    }
                case.failure(let error):
                    print(error)
                }
                
            })
        }
        else
        {
            showAlertView("" ,  message: "please check your network")
        }
    }
    
    
    //MARK: - UITEXTFIELD DELEGATE METHODS
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
    }
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
    }
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextField.DidEndEditingReason) {
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if let text = textField.text,
           let textRange = Range(range, in: text) {
            let updatedText = text.replacingCharacters(in: textRange,with: string)
            if updatedText == " " {
                return false
            }
            switch textField {
            case self.nameText:
                if (updatedText.count > 15) {
                    return  false
                } else {
                    return true
                }
            case self.emailText:
                if (updatedText.count > 250) {
                    return  false
                } else {
                    return true
                }
            case self.passwordText:
                if (updatedText.count > 50) {
                    return  false
                } else {
                    return true
                }
                
            case self.phoneNumberText:
                if (updatedText.count > 10) {
                    return  false
                } else {
                    return true
                }
            default:
                return true
            }
        }
        return true
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case nameText:
            emailText?.becomeFirstResponder()
        case emailText:
            passwordText?.becomeFirstResponder()
        case passwordText:
            phoneNumberText?.becomeFirstResponder()
            //        case passwordText:
            //             if (self.passwordField?.text != self.confirmPasswordField?.text )
            //            { self.showToast(message: "Password doesnot match", font: .systemFont(ofSize: 12.0))
            //                 confirmPasswordField?.becomeFirstResponder()
            //                 self.view.endEditing(true)
            //             }else{
            //            mobileField?.becomeFirstResponder()
            //             }
        default:
            phoneNumberText?.resignFirstResponder()
        }
        return true
    }
}

extension UIViewController {
    func popviewcntroller() {
        self.navigationController?.popViewController(animated: true)
    }

    func navigateToLoginViewController() {
        let story = UIStoryboard(name: "Main", bundle: nil)
        let vc = story.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    func navigateToSignUpViewController() {
        let story = UIStoryboard(name: "Main", bundle: nil)
        let vc = story.instantiateViewController(withIdentifier: "ViewController") as? ViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    func navigateToDashBoardViewController() {
        let story = UIStoryboard(name: "Main", bundle: nil)
        let vc = story.instantiateViewController(withIdentifier: "MDAccountSettingVC") as? MDAccountSettingVC
        self.navigationController?.pushViewController(vc!, animated: true)
    }


    func validationemailAddress(_ email : String) -> Bool {
        
        return true
    }
    

   
}

extension UIFont {
    
    public enum OpenSansType: String {
        case extraboldItalic = "-ExtraboldItalic"
        case semiboldItalic = "-SemiboldItalic"
        case semibold = "-Semibold"
        case regular = ""
        case lightItalic = "Light-Italic"
        case light = "-Light"
        case italic = "-Italic"
        case extraBold = "-Extrabold"
        case boldItalic = "-BoldItalic"
        case bold = "-Bold"
    }
    
    static func OpenSans(_ type: OpenSansType = .regular, size: CGFloat = UIFont.systemFontSize) -> UIFont {
        return UIFont(name: "OpenSans\(type.rawValue)", size: size)!
    }
    
    var isBold: Bool {
        return fontDescriptor.symbolicTraits.contains(.traitBold)
    }
    
    var isItalic: Bool {
        return fontDescriptor.symbolicTraits.contains(.traitItalic)
    }
    
}

extension UIView
{
    func viewPropeerty()
    {
        self.layer.cornerRadius = 10
    }
}


extension  UIViewController
{
    func showToast(message : String, font: UIFont) {
        let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2 - 75, y: self.view.frame.size.height-100, width: 180, height: 40))
        toastLabel.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        toastLabel.textColor = UIColor.white
        toastLabel.font = font
        toastLabel.textAlignment = .center
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 5
        toastLabel.clipsToBounds  =  true
        self.view.addSubview(toastLabel)
    }
    func showAlertView(_ title: String , message : String)
    {
        let alert = UIAlertController(title: title, message: message , preferredStyle:.alert)
        let okAction = UIAlertAction(title: "Ok", style: .default, handler:{alert in
            print("close")
        })
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
        
    }
    
    func containsDigit(_ value: String) -> Bool
    {
        let reqularExpression = ".*[0-9]+.*"
        let predicate = NSPredicate(format: "SELF MATCHES %@", reqularExpression)
        return !predicate.evaluate(with: value)
    }
    
    func containsLowerCase(_ value: String) -> Bool
    {
        let reqularExpression = ".*[a-z]+.*"
        let predicate = NSPredicate(format: "SELF MATCHES %@", reqularExpression)
        return !predicate.evaluate(with: value)
    }
    
    func containsUpperCase(_ value: String) -> Bool
    {
        let reqularExpression = ".*[A-Z]+.*"
        let predicate = NSPredicate(format: "SELF MATCHES %@", reqularExpression)
        return !predicate.evaluate(with: value)
    }
    func invalidPassword(_ value: String) -> String?
    {
        if value.count < 8
        {
            return "Password must be at least 8 characters"
        }
        if containsDigit(value)
        {
            return "Password must contain at least 1 digit"
        }
        if containsLowerCase(value)
        {
            return "Password must contain at least 1 lowercase character"
        }
        if containsUpperCase(value)
        {
            return "Password must contain at least 1 uppercase character"
        }
        return nil
    }
    
   
    
}
