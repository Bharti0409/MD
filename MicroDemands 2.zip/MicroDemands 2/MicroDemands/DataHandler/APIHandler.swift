////
////  APIHandler.swift
////  MicroDemands
////
////  Created by APPLE on 29/09/22.
////
//
//import UIKit
//
//class APIHandler: NSObject {
//static let shared = APIHandler()
//    var getBaseURL = UserDefaults.standard.string(forKey:"http://3.239.14.157:3002")
//    override init()
//    {
//        super.init()
//    }
//    func getRegisterData(with reqParameter: [String:Any], completeHandler: @escaping (_ isSuccess: Bool, _ response: NSDictionary?, _ errorMessage: String)-> () ){
//        let url = String(format: "", self.getBaseURL ?? "") ?? ""
//        self.postJson_Data(with: url, parameters: reqParameter){
//            isSuccess, response, errorMessage in
//            if isSuccess{
//                DispatchQueue.main.async {
//                    print("successs response:" ,response)
//                  //  NWUtility.hideCustomLoaderFromView()
//                    if ((response.value(value(forKey: "success") as? NSNumber ?? 0 ) == 1) {
//                        let dataDic = response.value(forKey: "result") as? NSDictionary ?? [:]
//                        if dataDic.count > 0{
//                            completeHandler(true, dataDic, errorMessage)
//                        }
//                        else{
//                            completeHandler(false, response, errorMessage)
//                        }
//                    }else{
//                        completeHandler(false, [:], errorMessage)
//                    }
//                }
//            }
//        }
//    }
//}
