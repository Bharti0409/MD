//
//  APIUrlPart.swift
//  MicroDemands
//
//  Created by APPLE on 19/09/22.
//

import Foundation
let mainPath:String = "http://3.239.14.157:3002"
let app_id = ""
let rest_key = ""
let apiSignup = "http://3.239.14.157:3002/v1/customer/register"
let apiLogin = "http://3.239.14.157:3002/v1/customer/login"
let otpApi = "http://3.239.14.157:3002/v1/customer/verifyOtp"
let forgotPassword = "http://3.239.14.157:3002/v1/customer/forgotPassword"
let resetPassword = "http://3.239.14.157:3002/v1/customer/reset-Password"
let resendOTP = "http://3.239.14.157:3002/v1/customer/resendOtp"
