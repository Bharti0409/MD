//
//  LocalStorage.swift
//  MicroDemands
//
//  Created by APPLE on 07/10/22.
//

import UIKit

class LocalStorage: NSObject
{
//static var myKey: String = "token"
    static var authToken = "token"
    static var defaults = UserDefaults.standard
    static var myValue: String {
        set{
            
            defaults.set(authToken, forKey: "authToken")
        }
        get {
            return UserDefaults.standard.string(forKey: authToken) ?? ""

        }
    }
}
