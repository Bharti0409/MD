import UIKit

class MDAccountSettingMC: NSObject {
    var logoImg     : String?
    var title       : String?
    var subTitle    : String?
    var isSwitch    : Bool?
    var id          : NSNumber?
    var isNotifTag  : NSNumber?
    var dataRowArray : [MDAccountSettingMC]?

    override init() {
        self.logoImg      = ""
        self.title        = ""
        self.subTitle     = ""
        self.isSwitch     = false
        self.id           = 0
        self.isNotifTag   = 0
        self.dataRowArray = []
    }

    class func getAccountSettingSerctionData() -> [MDAccountSettingMC] {

        let getDataArray : [[String: Any]] = MDAccountSettingMC.mainData()
        var dataArray : [MDAccountSettingMC] = []

        for index in 0..<getDataArray.count{
            let appDict = getDataArray[index]
            let model :MDAccountSettingMC = MDAccountSettingMC()
            model.title = appDict["title"] as? String ?? ""
            let arrayDic = appDict["rowArray"] as? NSArray ?? []
            model.dataRowArray = MDAccountSettingMC.getAccountSettingRowDataArray(arrayDic)
            dataArray.append(model)
        }
        return dataArray
    }


    class func getAccountSettingRowDataArray(_ appsArr : NSArray) -> [MDAccountSettingMC]{

        var dataArray: [MDAccountSettingMC] = []
        appsArr.enumerateObjects { object, indx, pointer in

            let dict = appsArr.object(at: indx) as? NSDictionary ?? [:]
            let model: MDAccountSettingMC = MDAccountSettingMC()

            model.logoImg        = dict.value(forKey: "logoImg") as? String ?? ""

            model.title        = dict.value(forKey: "title") as? String ?? ""
            model.subTitle     = dict.value(forKey: "subTitle") as? String ?? ""
            model.isSwitch     = dict.value(forKey: "icon") as? Bool ?? false
            model.id           = dict.value(forKey: "id") as? NSNumber ?? 0
            dataArray.append(model)
        }
        return dataArray
    }


    class func mainData() -> [[String: Any]]{

        let appArray : [[String: Any]] = [
                    //First Section
                    ["title" : "", "rowArray" :
                        [[ "title" : "Profile Information", "id": 1, "subTitle" : "Change your account information", "icon": false , "logoImg": "profile"],
                     [ "title" : "Change Password", "id": 2, "subTitle" : "Change your password", "icon": false , "logoImg": "lock"],
                     [ "title" : "Payment Methods", "id": 3, "subTitle" : "Add your credit & debit cards", "icon": false , "logoImg": "card"],
                     [ "title" : "Locations", "id": 4, "subTitle" : "Add or remove your delivery locations", "icon": false , "logoImg": "marker"],
                     [ "title" : "Add Social Account", "id": 5, "subTitle" : "Add Facebook, Twitter etc ", "icon": false , "logoImg": "facebook"],
                     [ "title" : "Refer to Friends", "id": 6, "subTitle" : "Get $10 for reffering friends", "icon": false , "logoImg": "share"]]],
                    //Second Section
                    ["title" : "Notifications", "rowArray" :
                    [[ "title" : "Push Notifications", "id": 1, "subTitle" : "For daily update you will get it", "icon": true, "logoImg": "notify"],
                     [ "title" : "SMS Notifications", "id": 2, "subTitle" : "For daily update you will get it", "icon": true, "logoImg": "notify"],
                     [ "title" : "Promotional Notifications", "id": 3, "subTitle" : "For daily update you will get it", "icon": true, "logoImg": "notify"]]],
                    //Third Section
                    ["title" : "MOre", "rowArray" :
                    [[ "title" : "Rate Us", "id": 1, "subTitle" : "Rate us playstore, appstor", "icon": false, "logoImg": "rating"],
                     [ "title" : "FAQ", "id": 2, "subTitle" : "Frequently asked questions", "icon": false , "logoImg": "Group 1723"],
                     [ "title" : "Logout", "id": 3, "subTitle" : "", "icon": false, "logoImg": "Group 1722"]]]

        ]

        return appArray
    }


}
