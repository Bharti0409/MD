import UIKit



class MDPaymentMC: NSObject {

    var image              : String?
    var cardType               : String?
    var subTitle             : String?
  

    override init(){

        super.init()

        self.image                             = ""
        self.cardType                           = ""
        self.subTitle                         = ""
       
      }

    

    class func getData() -> [MDPaymentMC]

    {

        let arrayJson:[[String: Any]] = self.subData()

        var dataArray:[MDPaymentMC] = []

        for index in 0..<arrayJson.count {

            let model = MDPaymentMC()

            let dictionary = arrayJson[index]

            model.image                         =     dictionary["Image"] as? String ?? ""
            model.cardType                       =     dictionary["CardType"] as? String ?? ""
            model.subTitle                     =     dictionary["SubTitle"] as? String ?? ""
           
            dataArray.append(model)
        }
        return dataArray
    }

    class func subData() -> [[String: Any]]

    {

        let jsonData: [[String: Any]] =

        [

            [

                "Image": "payPal",

                "CardType": "PayPal",

                "SubTitle": "Deafult Payment",

                

                ],

              [

                "Image": "Master",

                "CardType": "MasterCard",

                "SubTitle": "Not Deafult",

                
],

              [

                "Image": "Visa",

                "CardType": "Visa",

                "SubTitle": "Not Deafult",

              ]
        ]

        return jsonData

    }

}


