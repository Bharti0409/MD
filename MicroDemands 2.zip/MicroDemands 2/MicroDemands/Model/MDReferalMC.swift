//
//  MDReferalMC.swift
//  MicroDemands
//
//  Created by APPLE on 10/10/22.
//

import UIKit

class MDReferalMC: NSObject {
    var cardImage: String?
    var referTitle: String?
    var referSubTitle: String?
    var linkImage: String?
    var referLink: String?
    var cardBackgroundImage : String?
    
    override init()
    {
        super.init()
        self.cardBackgroundImage = ""
        self.cardImage = ""
        self.referTitle = ""
        self.referSubTitle = ""
        self.linkImage = ""
        self.referLink = ""

    }
    class func getData() -> [MDReferalMC]
    {
        var dataArray: [MDReferalMC] = []
        let arrayJson : [[String: Any]] = self.subData()
        for index in 0..<arrayJson.count
        {
            let model = MDReferalMC()
            let dictoionery = arrayJson[index]
            model.cardBackgroundImage = dictoionery ["cardBackgroundImage"]as? String ?? ""
            model.cardImage = dictoionery ["cardImage"]as? String ?? ""
            model.referTitle = dictoionery ["referTitle"] as? String ?? ""
            model.referSubTitle = dictoionery ["referSubTitle"] as? String ?? ""
            model.linkImage = dictoionery ["linkImage"] as? String ?? ""
            model.referLink = dictoionery ["referLink"] as? String ?? ""
            dataArray.append(model)

            
        }
        return dataArray
        
    }
    
    class func subData() -> [[String: Any]]
    {
        let jsonData: [[String: Any]] =
        [
            [
                "cardBackgroundImage" : "Oval",
                "cardImage" : "card 1",
       "referTitle" : "Refer a Friend, Get $10",
    "referSubTitle" : "Get $10 in Credits when someone sign up using your refer link","linkImage":"linkarrow",
        "referLink" : "https://ui8.net/76738b"
            ]
        ]
        return jsonData
            }
}
