      
//
//  MDSignupMC.swift
//  MicroDemands
//
//  Created by APPLE on 21/09/22.
//

import UIKit

class MDSignupMC: NSObject {
    
    var titleName:String?
    var placeholder:String?

    var textData :String?
    var checkIconBox :String?
    var countryCode: String?
    var CountryID: NSNumber?
    var id: NSNumber?
    var isShowPassword: Bool?

    override init() {
        self.titleName   = ""
        self.placeholder   = ""
        self.textData    = ""
        self.countryCode = ""
        self.CountryID   = 0
        self.checkIconBox = ""
        self.id   = 0
        self.isShowPassword =  false
    }
    
    class func getSignupTextFieldData() -> [MDSignupMC]{

        var dataArray : [MDSignupMC] = []
        //FULL NAME
        let model :MDSignupMC = MDSignupMC()
        model.titleName     = "FULL NAME"
        model.placeholder   = "Enter full name"
        model.textData      = ""
        model.checkIconBox  = "sUPCheckBox"
        model.id            = 1
        model.isShowPassword = false
        dataArray.append(model)

        //EMAIL
        let model1 :MDSignupMC = MDSignupMC()
        model1.titleName     = "EMAIL ADDRESS"
        model1.placeholder   = "Enter email address"
        model1.textData      = ""
        model1.checkIconBox  = "sUPCheckBox"
        model1.id            = 2
        model1.isShowPassword = false
        dataArray.append(model1)

        //PASSWORD
        let model2 :MDSignupMC = MDSignupMC()
        model2.titleName      = "PASSWORD"
        model2.placeholder    = "Enter Password"
        model2.textData       = ""
        model2.checkIconBox   = "sUPCheckBox"
        model2.id             = 3
        model2.isShowPassword = false
        dataArray.append(model2)

        //PHONE NUMBER
        let model3 :MDSignupMC = MDSignupMC()
        model3.titleName     = "PHONE NUMBER"
        model3.placeholder   = "Enter Phone Number "
        model3.textData      = ""
        model3.checkIconBox  = "sUPCheckBox"
        model3.id            = 4
        model3.isShowPassword = false
        dataArray.append(model3)

        //PASSWORD

        return dataArray
    }
}
