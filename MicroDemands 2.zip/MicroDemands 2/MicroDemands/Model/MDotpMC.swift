//
//  MDotpMC.swift
//  MicroDemands
//
//  Created by APPLE on 03/10/22.
//

import UIKit

class MDotpMC: NSObject {
    var gmail:String?
    var otp:String?
    var type:NSNumber?

    override init() {
        self.gmail = ""
        self.otp = ""
        self.type = 0

    }
    
    class func getOtpTextFieldData() -> [MDotpMC]{
        
        var dataArray : [MDotpMC] = []
        //FULL NAME
        let model :MDotpMC = MDotpMC()
        model.otp = ""
        dataArray.append(model)

        
        return dataArray

    }
    
    
}
